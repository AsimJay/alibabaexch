<?php 
$con = new mysqli('localhost', 'u423067381_game8_4', 'Asim123$', 'u423067381_game8_4');
// $con= new mysqli('localhost','root','','game5'); 
?>