<?php 
$con = new mysqli('localhost', 'u423067381_game7', 'Asim123$', 'u423067381_game7');
// $con= new mysqli('localhost','root','','game7'); 
?>