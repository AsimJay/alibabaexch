<?php 
$con = new mysqli('localhost', 'u423067381_game3_4', 'Asim123$', 'u423067381_game3_4');

// $con= new mysqli('localhost','root','','game3'); 
?>