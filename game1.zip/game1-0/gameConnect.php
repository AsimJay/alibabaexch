<?php 
$con = new mysqli('localhost', 'u423067381_game1_0', 'Asim123$', 'u423067381_game1_0');

// $con= new mysqli('localhost','root','','game1'); 
?>