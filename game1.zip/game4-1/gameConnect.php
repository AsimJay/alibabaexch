<?php 
$con = new mysqli('localhost', 'u423067381_game4_1', 'Asim123$', 'u423067381_game4_1');
// $con= new mysqli('localhost','root','','game4'); 
?>