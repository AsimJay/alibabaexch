<?php 
$con= new mysqli('localhost','asmitixc_asim','R;I6u]![&R@y','asmitixc_lottery_web'); 
// $con= new mysqli('localhost','root','','lottery_web'); 
?>