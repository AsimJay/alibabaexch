<?php
include "userAuth.php";
include "connect.php";
if (isset($_SESSION['username']) && isset($_SESSION['dealerID'])) {
    global $dealer, $dealerID;
    $dealer = $_SESSION['username'];
    $dealerID = $_SESSION['dealerID'];
}


$number = $_GET['number'];
$game = "Alibaba Exchange";
$defaultDatabase = "asmitixc_lottery_web";

if (isset($_GET['selected_db'])) {
    $selectedDatabase = $_GET['selected_db']; 
} else {
    $selectedDatabase = $defaultDatabase;
}

if ($number == 1) {
    printData($selectedDatabase, 'firstbiddetails', $con, $dealerID, 9);
} else if ($number == 2) {
    printData($selectedDatabase, 'secondbiddetails', $con, $dealerID, 9);
} else {
    printData($selectedDatabase, 'biddetails', $con, $dealerID, 99);
}

function printData($pdb, $db, $con, $dealerID, $maxBidNumber) {
    $amount = array_fill(0, $maxBidNumber + 1, 0);
// echo $dealerID;

    for ($i = 0; $i <= $maxBidNumber; $i++) {
        
        $query = "SELECT user_id, bid_number, bid_amount, did 
                    FROM `$pdb`.$db b INNER JOIN 
                    users u ON b.user_id = u.id WHERE u.did = $dealerID 
                    AND b.bid_number = $i;";
        // echo $query;
        $result = mysqli_query($con, $query);

        if (!$result) {
            die("Error in SQL query: " . mysqli_error($con));
        }

        while ($row = mysqli_fetch_assoc($result)) {
            $amount[$i] += $row['bid_amount'];
        }
    }

    $data = array();

    for ($i = 0; $i <= $maxBidNumber; $i++) {
        $data[] = array("number" => $i, "amount" => $amount[$i]);
    }

    header('Content-Type: application/json');
    echo json_encode($data);
    die();
}

mysqli_close($con);
?>
