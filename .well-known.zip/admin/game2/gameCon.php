<?php 
$con= new mysqli('localhost','asmitixc_asim','R;I6u]![&R@y','asmitixc_game2'); 
// $con= new mysqli('localhost','root','','game2'); 
?>