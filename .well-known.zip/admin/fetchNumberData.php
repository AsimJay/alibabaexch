<?php
// Replace with your database credentials
include "userAuth.php";
include "connect.php";

$number = $_GET['number'];
$digit = $_GET['number'];
// 0 - Double
// 1 - Open
// 2 - Close
$game = "Alibaba Exchange";
$defaultDatabase = "asmitixc_lottery_web"; // Make sure to validate and sanitize the input
// $query = "SELECT * FROM transactions, users WHERE transactions.user_id = users.id;";
if (isset($_GET['selected_db'])) {
    $selectedDatabase = $_GET['selected_db']; // Make sure to validate and sanitize the input
    
} else {
    // If not provided, assign a default database   
    $selectedDatabase = $defaultDatabase;
}

if ($number == 1) {
    $query = "SELECT * FROM `{$selectedDatabase}`.first_digit";
} else if ($number == 2) {
    $query = "SELECT * FROM `{$selectedDatabase}`.second_digit";
} else {
    $query = "SELECT * FROM `{$selectedDatabase}`.number_table";
} 
$result = mysqli_query($con, $query);

$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    // Format the number as two digits
    if(!$digit == 1 || !$digit == 2){
    $number = str_pad($row['number'], 2, '0', STR_PAD_LEFT);
    }else{
        $number = $row['number'];
    }
    // Add the formatted number to the data array
    $row['number'] = $number;
    $data[] = $row;
}

// Return the data as JSON
echo json_encode(array("data" => $data));

// Close the database connection
mysqli_close($con);
