<?php
include "userAuth.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Reset Transactions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container{
            margin: 50px;
        }
        .warning {
            color: red;
            font-weight: bold;
        }
        .reset-button {
            background-color: red;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
        .reset-button:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>
<?php include "aNav.php"; ?>
<div class="container">
<h1>Reset Transactions Table</h1>
<p class="warning">Warning: This action will reset the transactions table in the selected databases. This action is irreversible. Proceed with caution.</p>

<form method="post">
    <?php
    // Mapping of frontend names to backend database names
    $db_mapping = [
        "Alibaba-0" => "asmitixc_game1-0",
        "Alibaba Exchange" => "asmitixc_lottery_web",
        "Alibaba-1" => "asmitixc_game1",
        "Alibaba-2" => "asmitixc_game2",
        "Alibaba-3" => "asmitixc_game1-3",
        "Alibaba-4" => "asmitixc_game1-4",
        "Ak" => "asmitixc_game3",
        "Ak Close" => "asmitixc_game3-0",
        "Ak-1" => "asmitixc_game3-1",
        "Ak-2" => "asmitixc_game3-2",
        "Ak-3" => "asmitixc_game3-3",
        "Ak-4" => "asmitixc_game3-4",
        "Gm-0" => "asmitixc_game4-0",
        "Gm" => "asmitixc_game4",
        "Gm-1" => "asmitixc_game4-1",
        "Gm-2" => "asmitixc_game4-2",
        "Gm-3" => "asmitixc_game4-3",
        "Gm-4" => "asmitixc_game4-4",
        "Ls-0" => "asmitixc_game8-0",
        "Ls" => "asmitixc_game8",
        "Ls-1" => "asmitixc_game5",
        "Ls-2" => "asmitixc_game6",
        "Ls-3" => "asmitixc_game7",
        "Ls-4" => "asmitixc_game8-4"
    ];
    // Process form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {
        $servername = "localhost";
        $username = "asmitixc_asim";
        $password = "R;I6u]![&R@y";

        foreach ($db_mapping as $frontend_name => $backend_name) {
            if (isset($_POST[$frontend_name])) {
                // Create connection
                $conn = new mysqli($servername, $username, $password, $backend_name);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed to $backend_name: " . $conn->connect_error);
                }

                // Disable foreign key checks
                $conn->query("SET FOREIGN_KEY_CHECKS = 0");

                // SQL to truncate the transactions table
                $sql = "TRUNCATE TABLE transactions";
                echo $conn;
                if ($conn->query($sql) === TRUE) {
                    echo "Transactions table in $frontend_name has been reset successfully.<br>";
                } else {
                    echo "Error resetting transactions table in $frontend_name: " . $conn->error . "<br>";
                }

                // Enable foreign key checks
                $conn->query("SET FOREIGN_KEY_CHECKS = 1");

                $conn->close();
            }
        }
    }
    ?>

    <h2>Select Databases to Reset:</h2>
    <?php foreach ($db_mapping as $frontend_name => $backend_name): ?>
        <input type="checkbox" id="<?= htmlspecialchars($frontend_name) ?>" name="<?= htmlspecialchars($frontend_name) ?>" value="<?= htmlspecialchars($frontend_name) ?>">
        <label for="<?= htmlspecialchars($frontend_name) ?>"><?= htmlspecialchars($frontend_name) ?></label><br>
    <?php endforeach; ?>

    <br>
    <input type="submit" name="reset" value="Reset Selected Databases" class="reset-button">
</form>
</div>

</body>
</html>
