<?php include "userAuth.php"; 

//Defining the games 
// $games = array(
//     "gm0" => "game4-0",
//     "gm1" => "game4-1",
//     "gm2" => "game4-2",
//     "gm3" => "game4-3",
//     "gm4" => "game4-4",
//     "ac" => "game3-0",
//     "ak1" => "game3-1",
//     "ak2" => "game3-2",
//     "ak3" => "game3-3",
//     "ak4" => "game3-4",
//     "ls" => "game8",
//     "ls4" => "game8-4",
//     "ls0" => "game8-0",
//     "ab1" => "game1",
//     "ab0" => "game1-0",
//     "ab3" => "game1-3",
//     "ab4" => "game1-4",
//     "ab2" => "game2"
// );

// if (isset($_GET['g'])) {
//     $game = $_GET['g'];
// }
$newBalance = 0;
if(isset($_GET['b'])) {
    $newBalance = $_GET['b'];
}
$msgCode = array(
    1 => "Successfully purchased the numbers. ",
    2 => "Market Suspended.",
    3 => "Insufficient Balance. Please recharge your account.",
    4 => "Unable to bid.",
    5 => "New Balance: $newBalance",
    6 => "Bid Limit Exceed",
);

if (isset($_GET['m'])) {
    $m = $_GET['m'];
    $message = $msgCode[$m];
    if(isset($_GET['b']) && $m == 1){
        $message .= $msgCode[5];
    }
    echo '<script>alert("' . $message . '")</script>';
    redirect();
}

function redirect(){
    if (isset($_GET['gameDB'])){
        $gameDB = $_GET['gameDB'];
        echo '<script>setTimeout(function() { window.location.href = "http://abexch.online/'. $gameDB .'/2digit.php"; }, 0);</script>';
    }
}

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./css/index.css">
    <link rel="icon" href="./img/favicon.ico" type="image/x-icon">

    <title>Alibaba Exchange - Multi Digit</title>
</head>
<body>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@100;400&display=swap');
    body {
        background-color: #f7f7f7e3;
    }
    .container{
        padding: 3rem;
        margin: auto;
        width: 50%;
        padding: 10px;
        width: 30vw;
    }
    .form-container {
        color: #000;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        padding: 20px;
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 30vw;
    }
    input[type="text"],
    input[type="number"],
    select,
    .kBtn {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }
    .kBtn {
        background-color: #3a1e56d6;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .kBtn:hover{
        background-color: #3a1e56;
        color: #fff;
    }
    .display{
        text-align: left;
    }
    #digitsInput{
        letter-spacing: 1px;
    }
    @media screen and (max-width: 1200px) {
        .container {
            left: 0;
            padding: 1rem;
            width: auto;
        }
        .form-container{
            width: auto;
        }
    }
    </style>
    <?php include "kNav.php"; ?>
    <?php
    $id_json = json_encode($id); // Encode $id as JSON
    echo "<script>var id = $id_json;</script>";
    ?>
    <br><br>
    <div class="container">
        <div class="form-container">
        <h1>Multi Digit</h1>
        <form id="form">
            <select id="game" required>
                <option value="" disabled selected>Select Game</option>
                <option value="asmitixc_game1-0">Alibaba-0</option>
                <option value="=asmitixc_lottery_web">Alibaba Exchange</option>
                <option value="asmitixc_game1">Alibaba-1</option>
                <option value="asmitixc_game2">Alibaba-2</option>
                <option value="asmitixc_game1-3">Alibaba-3</option>
                <option value="asmitixc_game1-4">Alibaba-4</option>
                <option value="asmitixc_game3">Ak</option>
                <!-- <option value="asmitixc_game3-0">Ak Close</option> -->
                <option value="asmitixc_game3-1">Ak-1</option>
                <option value="asmitixc_game3-2">Ak-2</option>
                <option value="asmitixc_game3-3">Ak-3</option>
                <option value="asmitixc_game3-4">Ak-4</option>
                <option value="asmitixc_game4-0">Gm-0</option>
                <option value="asmitixc_game4">Gm</option>
                <option value="asmitixc_game4-1">Gm-1</option>
                <option value="asmitixc_game4-2">Gm-2</option>
                <option value="asmitixc_game4-3">Gm-3</option>
                <option value="asmitixc_game4-4">Gm-4</option>
                <option value="asmitixc_game8-0">Ls-0</option>
                <option value="asmitixc_game8">Ls</option>
                <option value="asmitixc_game5">Ls-1</option>
                <option value="asmitixc_game6">Ls-2</option>
                <option value="asmitixc_game7">Ls-3</option>
                <option value="asmitixc_game8-4">Ls-4</option>
            </select>
            <input type="text" id="digitsInput"  inputmode="numeric" pattern="\d{2}(,\d{2})*" pattern="[0-9]*" placeholder="Enter Digits Seperated by Comma (12, 34, 23, 76)" required>
            <input type="number" id="price" inputmode="numeric" pattern="[0-9]*" placeholder="Enter Price" min=5 required>
            <button type="submit" class="kBtn">Calculate</button>
            <div class="display">
                <p id="gameDisplay"></p>
                <p id="digits"></p>
                <p id="amountDisplay"></p>
                <p id="total"></p>
                <p id="totalAmount"></p>
            </div>
        </form>
        </div>
    </div>

    <script>
        // Controlling the Digit Inputs
        document.getElementById('digitsInput').addEventListener('input', function(event) {
        const input = event.target.value;
        const sanitizedInput = input.replace(/[^0-9,]/g, ''); // Remove characters other than digits and commas
        const formattedInput = formatInput(sanitizedInput); // Format input with commas
        event.target.value = formattedInput; // Update the input field value
        });
        // Add comma after every two digits
        function formatInput(input) {
            // Add comma after every two digits
            //return input.replace(/\d{2}(?=\d)/g, '$&,');

            // Alternative: Add comma after every two digits except the last one
            return input.replace(/\d{2}(?=\d)/g, '$&,');
        }



        document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('form').addEventListener('submit', function (event) {
            event.preventDefault();
            let game = document.getElementById('game')
            let digits = document.getElementById('digitsInput');
            let price = document.getElementById('price');
            let combo = seperateDigits();
            console.log(combo);

            let msg = document.getElementById('msg');
            let gameDisplay = document.getElementById('gameDisplay');
            let para = document.getElementById('digits');
            let amountDisplay = document.getElementById('amountDisplay');
            let totalPara = document.getElementById('total');
            let totalAmount = document.getElementById('totalAmount');

            // Filling up Values
            gameDisplay.textContent = "Game: " + game.options[game.selectedIndex].text;
            para.textContent = "";
            amountDisplay.textContent = "Price: Rs. " + price.value;
            let totalPrice =  price.value * combo.length;
            totalAmount.textContent = "Total Amount: Rs. " + formatPrice(totalPrice);
            totalPara.textContent = "";
            totalPara.textContent = "Total Digits: " + combo.length;
            for (var i = 0; i < combo.length; i++) {
                // Create a text node containing the current array element
                var textNode = document.createTextNode(combo[i]);
                // Append the text node to the <p> element
                para.appendChild(textNode);
                // Add a comma after each element, except the last one
                if (i < combo.length - 1) {
                    para.appendChild(document.createTextNode(", "));
                }
            }
            // alert(combo);
            // alert("All possible combinations for number " + number.value + ' : ' + combo + ".\nAmount: " + price.value);
            let purchaseBtn = document.createElement('a');
            purchaseBtn.href = generateURL(id, game, combo, price);
            purchaseBtn.textContent = 'Purchase';
            purchaseBtn.className = 'kBtn btn';
            purchaseBtn.id = 'purchaseBtn';
            // Checking if previous btn/a is there and if is then delete
            let existingPurchaseBtn = document.getElementById('purchaseBtn');
            if (existingPurchaseBtn) {
                existingPurchaseBtn.remove();
            }
            let displayDiv = document.getElementsByClassName('display')[0];
            displayDiv.appendChild(purchaseBtn)
          });
      });

    function seperateDigits() {
        const input = document.getElementById('digitsInput').value;
        const numbers = input.split(',').map(num => parseInt(num.trim(), 10));
        const validNumbers = numbers.filter(num => !isNaN(num) && num >= 0 && num <= 99);
        return validNumbers;
    }
      function generateCombinations(number) {
        let arrayOfDigits = number.toString().split('').map(Number);
        let combinations = [];
        // console.log(arrayOfDigits); // Output: [1, 2, 3, 4, 5]

        for (let i = 0; i < arrayOfDigits.length; i++) {
          for (let j = 0; j < arrayOfDigits.length; j++) {
            if (i != j) {
              let combination = ' ' + arrayOfDigits[i] + arrayOfDigits[j];
              combinations.push(parseInt(combination));
            }
          }
        }
        return combinations;
      }

      function formatPrice(price) {
        var priceStr = price.toString();
        var parts = priceStr.split(".");
        var integerPart = parts[0];
        var decimalPart = parts.length > 1 ? "." + parts[1] : "";
        var formattedIntegerPart = "";
        for (var i = integerPart.length - 1, j = 1; i >= 0; i--, j++) {
            formattedIntegerPart = integerPart[i] + formattedIntegerPart;
            if (j % 3 === 0 && i !== 0) {
                formattedIntegerPart = "," + formattedIntegerPart;
            }
        }

        // Combine the formatted integer part and the decimal part
        return formattedIntegerPart + decimalPart;
    }

    function generateURL(id, game, digits, price){
        let URL = "mTransaction.php?userID=" + encodeURIComponent(id) +"&game=" + encodeURIComponent(game.value) + "&number=" + encodeURIComponent(digits) + "&price=" + encodeURIComponent(price.value);
        return URL;
    }
    </script>
</body>