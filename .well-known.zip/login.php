<?php 
    include './admin/connect.php';
    // include 'userAuth.php';
    session_start();
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        //admin identification
        if($username == 'X1tRd7KqPz2' && $password == 'admin' ){
            $_SESSION['username'] = $username;
            header('Location: ./admin/games.php');
            exit;
        }
        // Dealer
        $sql = "SELECT dealerID, username, password, activation FROM dealer WHERE username='$username'";
        $result = $con->query($sql);
        if ($result->num_rows == 1) {
            // Verify password
            $row = $result->fetch_assoc();
            if ($password == $row['password']) {
                // Password is correct, set session variable and redirect to homepage
                if($row['activation']){
                    $_SESSION['username'] = $username;
                    $_SESSION['dealerID'] = $row['dealerID'];
                    header('Location: ./dealer/dealer.php');
                    exit;
                }else{
                    echo "<script>alert('Please contact your account provider to activate your account.'); window.location.href = 'login.html';</script>";
                }
            } else {
                // Password is incorrect
                echo "<script>alert('Invalid Password'); window.location.href = 'login.html';</script>";
            }
        }
        // User Authentication
        $sql = "SELECT * FROM users WHERE username='$username'";
        $result = $con->query($sql);
        if ($result->num_rows == 1) {
            // Verify password
            $row = $result->fetch_assoc();
            // echo $row['password'];
            if ($password == $row['password']) {
                // Password is correct, set session variable and redirect to homepage
                if($row['activation']){
                    $_SESSION['username'] = $username;
                    // header('Location: index.php');
                    header('Location: games.php');
                    exit;
                }else{
                    echo "<script>alert('Please contact your account provider to activate your account.'); window.location.href = 'login.html';</script>";
                }
            } else {
                // Password is incorrect
                // echo "Invalid password";
                // header('Location: login.html');
                echo "<script>alert('Invalid Password'); window.location.href = 'login.html';</script>";
            }
        } else {
            // User not found
            // echo "Invalid username";
            echo "<script>alert('Invalid Username'); window.location.href = 'login.html';</script>";
        }
        
        $con->close();
    }
    






    // include "connect.php";
    // $password = $_POST['password'];
    // echo $password;
    // if($password == "artitechStudio"){
    //     header("location:home.html");
    // }else{
    //     header("location:index.html");
    // }
