<style>
.kainchi_link{
	color: red !important;
	animation: myAnim 2s ease 0s infinite normal forwards;
}
.kainchi_link a{
	font-weight: 900;
	color: red !important;
}
@keyframes myAnim {
	0%,
	50%,
	100% {
		opacity: 1;
	}

	25%,
	75% {
		opacity: 0;
	}
}

</style>