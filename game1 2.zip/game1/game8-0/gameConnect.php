<?php 
$con = new mysqli('localhost', 'u423067381_game8_0', 'Asim123$', 'u423067381_game8_0');
// $con= new mysqli('localhost','root','','game5'); 
?>