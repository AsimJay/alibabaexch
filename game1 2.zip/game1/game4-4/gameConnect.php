<?php 
$con = new mysqli('localhost', 'u423067381_game4_4', 'Asim123$', 'u423067381_game4_4');
// $con= new mysqli('localhost','root','','game4'); 
?>