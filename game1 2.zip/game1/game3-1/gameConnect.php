<?php 
$con = new mysqli('localhost', 'u423067381_game3_1', 'Asim123$', 'u423067381_game3_1');

// $con= new mysqli('localhost','root','','game3'); 
?>