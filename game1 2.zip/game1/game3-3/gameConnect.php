<?php 
$con = new mysqli('localhost', 'u423067381_game3_3', 'Asim123$', 'u423067381_game3_3');

// $con= new mysqli('localhost','root','','game3'); 
?>