<?php 
$con = new mysqli('localhost', 'u423067381_game1', 'Asim123$', 'u423067381_game1');
// $con= new mysqli('localhost','root','','game1'); 
?>