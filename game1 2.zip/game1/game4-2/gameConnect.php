<?php 
$con = new mysqli('localhost', 'u423067381_game4_2', 'Asim123$', 'u423067381_game4_2');
// $con= new mysqli('localhost','root','','game4'); 
?>