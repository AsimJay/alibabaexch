<?php 
$con = new mysqli('localhost', 'u423067381_game5', 'Asim123$', 'u423067381_game5');
// $con= new mysqli('localhost','root','','game5'); 
?>