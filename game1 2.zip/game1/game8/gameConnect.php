<?php 
$con = new mysqli('localhost', 'u423067381_game8', 'Asim123$', 'u423067381_game8');
// $con= new mysqli('localhost','root','','game5'); 
?>