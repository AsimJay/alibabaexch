<?php 
$con = new mysqli('localhost', 'u423067381_game2', 'Asim123$', 'u423067381_game2');

// $con= new mysqli('localhost','root','','game1'); 
?>