<?php 
$con = new mysqli('localhost', 'u423067381_game3', 'Asim123$', 'u423067381_game3');

// $con= new mysqli('localhost','root','','game3'); 
?>